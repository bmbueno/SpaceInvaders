package View

import javax.swing.{JFrame,WindowConstants, JLabel, JPanel, ImageIcon}
import java.awt.event._
import java.awt.Color
import java.awt.Dimension
import Controller._
import java.time._

class UI() extends JFrame with KeyListener {
  private val titulo: String = "Space Invaders"
  private var tecla: Int = 0
  private var controle: Controller = new Controller()
  private var img: ImageIcon = new ImageIcon("naveImage.jpg")
  private var labelNave: JLabel = new JLabel()
//  private var labelNave: JLabel = new JLabel(img)
  private var labelDisparo: JLabel = new JLabel()
  private var labelAlien: JLabel = new JLabel()
  private var tela: JFrame = new JFrame()
  private var panel: JPanel = new JPanel();

  panel.setBackground(Color.black)

  def iniciar(): Unit ={
    this.tela.setTitle(titulo);
    this.tela.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    this.tela.setSize(600, 600);
    this.tela.setLocationRelativeTo(null);
    this.tela.addKeyListener(this)
    this.tela.setResizable(false);

  }

  def keyPressed(k:KeyEvent): Unit = {
      controle.setTecla(k.getKeyCode)
  }
  def keyReleased(k:KeyEvent): Unit = {
  }

  def keyTyped(k:KeyEvent): Unit = {
  }

  def printNave(): Unit = {
    this.labelNave.setText("A")
    this.labelNave.setForeground(Color.white)
    this.panel.add(this.labelNave)
    this.panel.setBounds(0,0,600,600)
    this.panel.setLayout(null)
    this.tela.add(this.panel)
    this.labelNave.setBounds(controle.getNave.getX,controle.getNave.getY,10,10)
    this.tela.setVisible(true)

  }
}
