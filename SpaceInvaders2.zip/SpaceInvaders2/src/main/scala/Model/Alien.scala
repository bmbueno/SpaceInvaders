package Model

class Alien(coordX: Int, coordY: Int) extends Disparo(coordX,coordY){

  def moveDireita(): Unit = {
    this.x = this.x + 10
  }
  def moveEsquerda(): Unit = {
    this.x = this.x + 10
  }
}
