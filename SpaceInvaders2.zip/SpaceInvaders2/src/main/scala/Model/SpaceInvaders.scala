package Model

import View.UI

object SpaceInvaders {
  def main(args: Array[String]): Unit = {

    var interface: UI = new UI()

    interface.iniciar()

    interface.printNave()





}
}
