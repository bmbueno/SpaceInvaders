package Model

class Nave(coordX: Int, coordY: Int) extends Alien(coordX,coordY){

  def moveTras(): Unit = {
    this.y = this.y - 10
  }
}
