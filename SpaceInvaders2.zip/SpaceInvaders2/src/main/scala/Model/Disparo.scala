package Model

class Disparo(coordX: Int, coordY: Int, ativo: Boolean = true){
  protected var x: Int = coordX
  protected var y: Int = coordY
  protected var velocidade: Int = 1

  def moveFrente(): Unit = {
    this.y = this.y + 10
  }

  def getX = x
  def getY = y
}
